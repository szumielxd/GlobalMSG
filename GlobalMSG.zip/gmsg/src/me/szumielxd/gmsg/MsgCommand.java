package me.szumielxd.gmsg;

import net.md_5.bungee.api.ChatColor;
import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.ProxyServer;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.md_5.bungee.api.plugin.Command;

public class MsgCommand extends Command {
	
	public MsgCommand() {
		super(ConfigLoader.getMsgCommand());
	}

	@Override
	public void execute(CommandSender s, String[] arg) {
		if(s.hasPermission("gmsg.use")){
			if(arg.length==1&&(arg[0].equalsIgnoreCase("reload")||arg[0].equalsIgnoreCase("rl"))) {
				if(s.hasPermission("gmsg.reload")) {
					ConfigLoader.checkFiles();
					ConfigLoader.loadConfig();
					
					s.sendMessage(new TextComponent(ChatColor.translateAlternateColorCodes('&', ConfigLoader.getReloadComplete())));
				}else {
					if(!ConfigLoader.getPermErrMsg().equals("null"))s.sendMessage(new TextComponent(ChatColor.translateAlternateColorCodes('&', ConfigLoader.getPermErrMsg())));
				}
				return;
			}
			if(arg.length>1) {
				ProxiedPlayer p = ProxyServer.getInstance().getPlayer(arg[0]);
				if(p==null) {
					String mess = ConfigLoader.getOfflineErr();
					mess = mess.replaceAll("%target%", arg[0]);
					s.sendMessage(new TextComponent(ChatColor.translateAlternateColorCodes('&', mess)));
					return;
				}
				//budowa msg
				String msg = new String();
				for(int i=1; i<arg.length; i++) {
					msg = new String(msg+" "+arg[i]);
				}
				
				String toTarget = ConfigLoader.getTargetMsg();
				toTarget = toTarget.replaceAll("%sender%", s.getName());
				toTarget = toTarget.replaceAll("%target%", p.getName());
				toTarget = toTarget.replaceAll("%msg%", msg);
				if(s instanceof ProxiedPlayer) {
					ProxiedPlayer sp = (ProxiedPlayer) s;
					toTarget = toTarget.replaceAll("%sServer%", sp.getServer().getInfo().getName());
				}else toTarget = toTarget.replaceAll("%sServer%", "");
				toTarget = toTarget.replaceAll("%tServer%", p.getServer().getInfo().getName());
				
				String toSender = ConfigLoader.getSenderMsg();
				toSender = toSender.replaceAll("%target%", p.getName());
				toSender = toSender.replaceAll("%sender%", s.getName());
				toSender = toSender.replaceAll("%msg%", msg);
				if(s instanceof ProxiedPlayer) {
					ProxiedPlayer sp = (ProxiedPlayer) s;
					toSender = toSender.replaceAll("%sServer%", sp.getServer().getInfo().getName());
				}else toSender = toSender.replaceAll("%sServer%", "");
				toSender = toSender.replaceAll("%tServer%", p.getServer().getInfo().getName());
				
				p.sendMessage(new TextComponent(ChatColor.translateAlternateColorCodes('&', toTarget)));
				s.sendMessage(new TextComponent(ChatColor.translateAlternateColorCodes('&', toSender)));
			}else s.sendMessage(new TextComponent(ChatColor.translateAlternateColorCodes('&', ConfigLoader.getCommandUsage())));
		}else {
			if(!ConfigLoader.getPermErrMsg().equals("null")) s.sendMessage(new TextComponent(ChatColor.translateAlternateColorCodes('&', ConfigLoader.getPermErrMsg())));
		}
	}

}
