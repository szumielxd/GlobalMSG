package me.szumielxd.gmsg;

import net.md_5.bungee.api.plugin.Plugin;

public class Main extends Plugin {
	
	private static Main instance;
	public static Main getInst() {
		return instance;
	}
	
	@Override
	public void onEnable() {
		
		instance = this;
		ConfigLoader.checkFiles();
		ConfigLoader.loadConfig();
		
		this.getProxy().getPluginManager().registerCommand(this, new MsgCommand());
	}

}
