package me.szumielxd.gmsg;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;

import net.md_5.bungee.config.Configuration;
import net.md_5.bungee.config.ConfigurationProvider;
import net.md_5.bungee.config.YamlConfiguration;

public class ConfigLoader {
	
	private static Configuration config;
	
	private static String permErrMsg;
	private static String senderMsg;
	private static String targetMsg;
	private static String offlineErr;
	private static String msgCommand;
	private static String commandUsage;
	private static String reloadComplete;
	
	private static File conf;
	
	public static void loadConfig() {
		try {
			config = ConfigurationProvider.getProvider(YamlConfiguration.class).load(new File(Main.getInst().getDataFolder(), "config.yml"));
		} catch (IOException e) {
			permErrMsg = "null";
			senderMsg = "&6&lGlobal: &2[%sServer%]%sender%&a->&2[%tServer%]%target%&e&l� &7%msg%";
			senderMsg = "&6&lGlobal: &2[%tServer%]%target%&a->&2[%sServer%]%sender%&e&l� &7%msg%";
			msgCommand = "gmsg";
			commandUsage = "&6Uzyj /gmsg <gracz> <wiadomosc>";
			offlineErr = "&c%target% sie schowal i go nie ma";
			reloadComplete = "&6Pomyslnie odswiezono config GlobalMsg";
			checkFiles();
		}
		if(config != null) {
			permErrMsg = config.getString("permErrMsg");
			senderMsg = config.getString("senderMsg");
			targetMsg = config.getString("targetMsg");
			offlineErr = config.getString("offlineErr");
			msgCommand = config.getString("msgCommand");
			commandUsage = config.getString("commandUsage");
			reloadComplete = config.getString("reloadComplete");
			if(permErrMsg == null || senderMsg == null || targetMsg == null || offlineErr == null || msgCommand == null || commandUsage == null || reloadComplete == null) {
				conf.delete();
				checkFiles();
			}
		}
	}
	
	public static void saveConfig() {
		try {
			ConfigurationProvider.getProvider(YamlConfiguration.class).save(config, new File(Main.getInst().getDataFolder(), "config.yml"));
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	
	public static void checkFiles() {
		if(!Main.getInst().getDataFolder().exists()) Main.getInst().getDataFolder().mkdir();
		conf = new File(Main.getInst().getDataFolder(), "config.yml");
		if(!conf.exists()) {
			try(InputStream in = Main.getInst().getResourceAsStream("config.yml")){
				Files.copy(in, conf.toPath());
			}catch(IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	
	public static String getSenderMsg() {
		return senderMsg;
	}
	public static String getTargetMsg() {
		return targetMsg;
	}
	public static String getPermErrMsg() {
		return permErrMsg;
	}
	public static String getMsgCommand() {
		return msgCommand;
	}
	public static String getCommandUsage() {
		return commandUsage;
	}
	public static String getOfflineErr() {
		return offlineErr;
	}
	public static String getReloadComplete() {
		return reloadComplete;
	}

}
